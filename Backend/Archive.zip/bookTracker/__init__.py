from flask import Flask 
from flask_migrate import Migrate 
from flask_cors import CORS
from flask_jwt_extended import JWTManager
import os
from dotenv import load_dotenv

# Load environment variables from .env
load_dotenv()

#factory
def create_app(): 
    app = Flask(__name__)
    CORS(app, resources={r"/*": {"origins": os.getenv('FRONTEND_ORIGIN')}})

    #database config
    app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('SQLALCHEMY_DATABASE_URI')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False  
    app.config['DEBUG'] = os.getenv('DEBUG', False)

    # JWT Secret Key
    app.config['JWT_SECRET_KEY'] = os.getenv('JWT_SECRET_KEY', 'super-secret-key')

    # Initialize JWTManager
    jwt = JWTManager(app)
    from . import models

    models.db.init_app(app)
    migrate = Migrate(app, models.db)

    # CORS and Preflight request handling
    @app.after_request
    def after_request(response):
        response.headers.add('Access-Control-Allow-Origin', os.getenv('FRONTEND_ORIGIN')) 
        response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
        response.headers.add('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS')
        return response

    from . import mybook
    app.register_blueprint(mybook.bp)

    from . import routes
    app.register_blueprint(routes.auth_bp)

    from . import login
    app.register_blueprint(login.auth_bp)

    # return the app 
    return app

if __name__ == "__main__":
    app = create_app()
    port = int(os.getenv('PORT', 8000))  # Use port from .env, default to 8000 if not set
    app.run(host='0.0.0.0', port=port)
